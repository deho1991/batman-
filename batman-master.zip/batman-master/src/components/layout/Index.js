import React from 'react'
import Lists from '../lists/Lists';

const Index = () => {
    return (
        <React.Fragment>
            <Lists/>
        </React.Fragment>
    )
}

export default Index;